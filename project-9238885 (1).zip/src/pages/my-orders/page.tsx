import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';

interface UserRobot {
  id: number;
  robot_id: number;
  robot_name: string;
  category: string;
  price: number;
  daily_return: number;
  image: string;
  purchased_at: string;
  total_earned: number;
  active: boolean;
}

const statusBadge = (active: boolean) =>
  active
    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-400/20'
    : 'bg-red-500/10 text-red-400 border border-red-400/20';

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Math.floor((Date.now() - d.getTime()) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return d.toLocaleDateString();
}

export default function MyOrdersPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<UserRobot[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'price-high' | 'price-low'>('newest');

  useEffect(() => {
    async function loadOrders() {
      if (!supabase) { setLoading(false); return; }
      setLoading(true);
      const uid = user?.id ?? 'demo-user-001';
      const { data, error } = await supabase
        .from('user_robots')
        .select('*')
        .eq('user_id', uid)
        .order('purchased_at', { ascending: false });
      if (!error && data) {
        setOrders(data as UserRobot[]);
      }
      setLoading(false);
    }
    loadOrders();
  }, [user?.id]);

  const filtered = orders
    .filter((o) => {
      const matchesSearch =
        o.robot_name.toLowerCase().includes(search.toLowerCase()) ||
        o.category.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        filterStatus === 'all'
          ? true
          : filterStatus === 'active'
          ? o.active
          : !o.active;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.purchased_at).getTime() - new Date(a.purchased_at).getTime();
      if (sortBy === 'oldest') return new Date(a.purchased_at).getTime() - new Date(b.purchased_at).getTime();
      if (sortBy === 'price-high') return Number(b.price) - Number(a.price);
      if (sortBy === 'price-low') return Number(a.price) - Number(b.price);
      return 0;
    });

  const totalSpent = orders.reduce((sum, o) => sum + Number(o.price), 0);
  const totalEarned = orders.reduce((sum, o) => sum + Number(o.total_earned), 0);
  const activeCount = orders.filter((o) => o.active).length;

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      {/* Header */}
      <div className="border-b border-dark-700/50">
        <div className="flex items-center justify-between px-4 md:px-6 py-4">
          <Link to="/" className="inline-flex items-center gap-2 shrink-0">
            <img
              src="https://static.readdy.ai/image/e514fc972d3ac011ec046bb027a8bd60/05b8712378af54b96f49b8eeeac4fc04.png"
              alt="Ai EARNERS Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="text-white font-bold text-lg tracking-tight whitespace-nowrap">
              Ai <span className="text-gold-400">EARNERS</span>
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link
              to="/dashboard"
              className="text-sm text-white/60 hover:text-white transition-colors flex items-center gap-1 whitespace-nowrap"
            >
              <i className="ri-dashboard-line w-4 h-4 flex items-center justify-center" />
              Dashboard
            </Link>
          </div>
        </div>
      </div>

      <div className="px-4 md:px-6 py-8 md:py-12">
        <div className="max-w-6xl mx-auto">
          {/* Title + Stats */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-1">My Orders</h1>
              <p className="text-sm text-white/50">Your complete robot purchase history</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-surface-card border border-dark-700/40 rounded-lg px-4 py-2 text-center">
                <div className="text-xs text-white/40">Orders</div>
                <div className="text-sm font-bold text-white">{orders.length}</div>
              </div>
              <div className="bg-surface-card border border-dark-700/40 rounded-lg px-4 py-2 text-center">
                <div className="text-xs text-white/40">Active</div>
                <div className="text-sm font-bold text-emerald-400">{activeCount}</div>
              </div>
              <div className="bg-surface-card border border-dark-700/40 rounded-lg px-4 py-2 text-center">
                <div className="text-xs text-white/40">Spent</div>
                <div className="text-sm font-bold text-gold-400">₦{totalSpent.toLocaleString()}</div>
              </div>
              <div className="bg-surface-card border border-dark-700/40 rounded-lg px-4 py-2 text-center">
                <div className="text-xs text-white/40">Earned</div>
                <div className="text-sm font-bold text-white">₦{totalEarned.toLocaleString()}</div>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <div className="relative flex-1">
              <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-white/30 text-xs w-4 h-4 flex items-center justify-center" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search robots..."
                className="w-full bg-dark-800 border border-dark-700/50 rounded-md pl-9 pr-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-gold-400/50 transition-colors"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="bg-dark-800 border border-dark-700/50 rounded-md px-3 py-2 text-sm text-white focus:outline-none focus:border-gold-400/50 transition-colors"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-dark-800 border border-dark-700/50 rounded-md px-3 py-2 text-sm text-white focus:outline-none focus:border-gold-400/50 transition-colors"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="price-high">Price: High to Low</option>
              <option value="price-low">Price: Low to High</option>
            </select>
          </div>

          {/* Orders Table */}
          <div className="bg-surface-card border border-dark-700/40 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-dark-700/40">
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider">Robot</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider hidden sm:table-cell">Category</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider">Price</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider hidden md:table-cell">Daily Return</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider hidden md:table-cell">Purchased</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider hidden lg:table-cell">Total Earned</th>
                    <th className="px-5 py-3 text-[10px] text-white/40 font-medium uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-8 text-center text-sm text-white/40">
                        Loading your orders...
                      </td>
                    </tr>
                  ) : filtered.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-8 text-center text-sm text-white/40">
                        {orders.length === 0
                          ? 'You have not purchased any robots yet.'
                          : 'No orders match your filters.'}
                      </td>
                    </tr>
                  ) : (
                    filtered.map((o) => (
                      <tr key={o.id} className="border-b border-dark-700/30 hover:bg-dark-800/30 transition-colors">
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-3">
                            <img
                              src={o.image}
                              alt={o.robot_name}
                              className="w-10 h-10 rounded-md object-cover object-top shrink-0"
                            />
                            <div className="min-w-0">
                              <div className="text-sm text-white font-medium truncate">{o.robot_name}</div>
                              <div className="text-[10px] text-white/40">ID: {o.robot_id}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-sm text-white/60 hidden sm:table-cell">{o.category}</td>
                        <td className="px-5 py-3.5 text-sm text-gold-400 font-medium">₦{Number(o.price).toLocaleString()}</td>
                        <td className="px-5 py-3.5 text-sm text-emerald-400 hidden md:table-cell">+₦{o.daily_return}/day</td>
                        <td className="px-5 py-3.5 text-[10px] text-white/40 hidden md:table-cell">
                          <div>{new Date(o.purchased_at).toLocaleDateString()}</div>
                          <div className="text-white/25">{timeAgo(o.purchased_at)}</div>
                        </td>
                        <td className="px-5 py-3.5 text-sm text-white/60 hidden lg:table-cell">
                          ₦{Number(o.total_earned).toLocaleString()}
                        </td>
                        <td className="px-5 py-3.5">
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${statusBadge(o.active)}`}>
                            {o.active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Empty state CTA */}
          {!loading && orders.length === 0 && (
            <div className="mt-6 text-center">
              <Link
                to="/#robots"
                className="inline-flex items-center justify-center bg-gold-500 hover:bg-gold-600 text-dark-900 font-semibold px-6 py-2.5 rounded-md transition-colors text-sm"
              >
                <i className="ri-robot-2-line w-4 h-4 flex items-center justify-center mr-1.5" />
                Browse Robots
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}